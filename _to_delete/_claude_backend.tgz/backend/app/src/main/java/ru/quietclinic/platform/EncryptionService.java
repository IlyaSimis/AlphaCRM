package ru.quietclinic.platform;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

public interface EncryptionService {
  String encrypt(String plaintext);

  String decrypt(String ciphertext);
}

interface KmsPort {
  byte[] dataKey();

  String keyVersion();
}

@Service
class DevKmsAdapter implements KmsPort {
  private final byte[] key;

  DevKmsAdapter(@Value("${clinic.dev-kms-key:local-dev-key-change-me}") String source) {
    try {
      key = MessageDigest.getInstance("SHA-256").digest(source.getBytes(StandardCharsets.UTF_8));
    } catch (Exception ex) {
      throw new IllegalStateException(ex);
    }
  }

  public byte[] dataKey() {
    return key.clone();
  }

  public String keyVersion() {
    return "dev-v1";
  }
}

@Service
class AesGcmEncryptionService implements EncryptionService {
  private final KmsPort kms;
  private final SecureRandom random = new SecureRandom();

  AesGcmEncryptionService(KmsPort kms) {
    this.kms = kms;
  }

  public String encrypt(String plaintext) {
    if (plaintext == null) return null;
    try {
      var nonce = new byte[12];
      random.nextBytes(nonce);
      var cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(
          Cipher.ENCRYPT_MODE,
          new SecretKeySpec(kms.dataKey(), "AES"),
          new GCMParameterSpec(128, nonce));
      var encrypted = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
      return kms.keyVersion()
          + "."
          + Base64.getUrlEncoder()
              .withoutPadding()
              .encodeToString(
                  ByteBuffer.allocate(nonce.length + encrypted.length)
                      .put(nonce)
                      .put(encrypted)
                      .array());
    } catch (Exception ex) {
      throw new IllegalStateException("Шифрование не выполнено", ex);
    }
  }

  public String decrypt(String ciphertext) {
    if (ciphertext == null) return null;
    try {
      var encoded = ciphertext.substring(ciphertext.indexOf('.') + 1);
      var packed = Base64.getUrlDecoder().decode(encoded);
      var nonce = java.util.Arrays.copyOfRange(packed, 0, 12);
      var encrypted = java.util.Arrays.copyOfRange(packed, 12, packed.length);
      var cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(
          Cipher.DECRYPT_MODE,
          new SecretKeySpec(kms.dataKey(), "AES"),
          new GCMParameterSpec(128, nonce));
      return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    } catch (Exception ex) {
      throw new IllegalStateException("Расшифрование не выполнено", ex);
    }
  }
}
