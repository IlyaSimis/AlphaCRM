package ru.quietclinic.scheduling;

import static ru.quietclinic.platform.PlatformConfig.actorId;
import static ru.quietclinic.platform.PlatformConfig.clinicId;
import static ru.quietclinic.platform.PlatformConfig.conflict;
import static ru.quietclinic.platform.PlatformConfig.forbidden;
import static ru.quietclinic.platform.PlatformConfig.hasRole;
import static ru.quietclinic.platform.PlatformConfig.notFound;
import static ru.quietclinic.platform.PlatformConfig.requireRole;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.quietclinic.audit.AuditService;
import ru.quietclinic.billing.ChargeService;
import ru.quietclinic.clinical.CareRelationshipService;
import ru.quietclinic.communications.OutboxService;
import ru.quietclinic.platform.ClinicTime;

/** Записи на приём: расписание, история, создание, перенос, отмена и смена статуса. */
@Service
class AppointmentService {
  static final int MAX_RANGE_DAYS = 3 * 366;
  static final Set<String> RESCHEDULABLE = Set.of("BOOKED", "CONFIRMED");
  /** Основание в аудите для действий пациента через Telegram-бота. */
  static final String ONLINE = "telegram-bot";

  private final AppointmentRepository appointments;
  private final PractitionerScheduleRepository workingHours;
  private final ClinicServiceRepository services;
  private final CareRelationshipService careRelationships;
  private final ChargeService charges;
  private final AuditService audit;
  private final OutboxService outbox;
  private final ClinicScope clinic;
  private final ClinicTime time;

  AppointmentService(
      AppointmentRepository appointments,
      PractitionerScheduleRepository workingHours,
      ClinicServiceRepository services,
      CareRelationshipService careRelationships,
      ChargeService charges,
      AuditService audit,
      OutboxService outbox,
      ClinicScope clinic,
      ClinicTime time) {
    this.appointments = appointments;
    this.workingHours = workingHours;
    this.services = services;
    this.careRelationships = careRelationships;
    this.charges = charges;
    this.audit = audit;
    this.outbox = outbox;
    this.clinic = clinic;
    this.time = time;
  }

  /**
   * Либо один день ({@code date}), либо диапазон {@code from}–{@code to} включительно, например вся
   * история пациента. Фильтры по пациенту, врачу и статусу необязательны.
   */
  @Transactional(readOnly = true)
  List<AppointmentView> find(AppointmentQuery query) {
    requireRole("ADMINISTRATOR", "DOCTOR", "NURSE", "CASHIER", "MANAGER");
    LocalDate from;
    LocalDate to;
    if (query.date() != null) {
      from = query.date();
      to = query.date();
    } else if (query.from() != null && query.to() != null) {
      from = query.from();
      to = query.to();
      if (to.isBefore(from)) {
        throw conflict("INVALID_RANGE", "Period end must not be before its start");
      }
      if (ChronoUnit.DAYS.between(from, to) >= MAX_RANGE_DAYS) {
        throw conflict("RANGE_TOO_LONG", "Period must not exceed three years");
      }
    } else {
      throw conflict("INVALID_RANGE", "Pass a day (date) or a period (from and to)");
    }
    // День — в часовом поясе клиники.
    var start = time.startOf(from);
    var end = time.startOf(to.plusDays(1));
    var rows =
        query.patientId() == null
            ? appointments.findByStartsAtGreaterThanEqualAndStartsAtLessThanOrderByStartsAt(
                start, end)
            : appointments
                .findByPatientIdAndStartsAtGreaterThanEqualAndStartsAtLessThanOrderByStartsAt(
                    query.patientId(), start, end);
    // Только записи к врачам своей клиники.
    var ownPractitioners = clinic.practitionerIds();
    return rows.stream()
        .filter(a -> ownPractitioners.contains(a.practitionerId))
        .filter(a -> query.patientId() == null || a.patientId.equals(query.patientId()))
        .filter(
            a -> query.practitionerId() == null || a.practitionerId.equals(query.practitionerId()))
        .filter(a -> query.status() == null || a.status.equals(query.status()))
        .map(AppointmentView::of)
        .toList();
  }

  @Transactional
  AppointmentView create(CreateAppointmentRequest request) {
    requireRole("ADMINISTRATOR", "DOCTOR");
    var service = activeService(request.serviceName());
    if (!clinic.hasPatient(request.patientId())) {
      throw notFound("PATIENT_NOT_FOUND", "Patient not found");
    }
    return book(
        request.patientId(),
        request.practitionerId(),
        request.startsAt(),
        request.endsAt(),
        service,
        "booking",
        false);
  }

  /**
   * Запись, которую пациент сделал сам в Telegram-боте. Проверки слота те же, что у регистратуры;
   * конец приёма — по длительности услуги. Права проверяет {@link OnlineBooking}.
   */
  @Transactional
  AppointmentView createOnline(
      UUID patientId, UUID practitionerId, Instant startsAt, String serviceName) {
    var service = activeService(serviceName);
    if (!clinic.hasPatient(patientId)) throw notFound("PATIENT_NOT_FOUND", "Patient not found");
    var endsAt = startsAt.plus(Duration.ofMinutes(service.durationMinutes));
    return book(patientId, practitionerId, startsAt, endsAt, service, ONLINE, true);
  }

  /** Пациент подтвердил запись кнопкой в Telegram. Уже подтверждённая остаётся как есть. */
  @Transactional
  AppointmentView confirmByPatient(UUID id) {
    var appointment = find(id);
    if ("CONFIRMED".equals(appointment.status)) return AppointmentView.of(appointment);
    if (!"BOOKED".equals(appointment.status)) {
      throw conflict(
          "INVALID_STATUS_TRANSITION",
          "Cannot confirm an appointment in status " + appointment.status);
    }
    appointment.status = "CONFIRMED";
    appointments.saveAndFlush(appointment);
    audit.record(
        actorId(),
        "APPOINTMENT_STATUS_CHANGED",
        "APPOINTMENT",
        appointment.id,
        "ALLOWED",
        "BOOKED->CONFIRMED");
    return AppointmentView.of(appointment);
  }

  /**
   * Пациент сам отменил запись в Telegram. Сообщение об отмене не ставится: пациент только что
   * увидел ответ бота; неотправленное напоминание доставщик закроет сам по статусу записи.
   */
  @Transactional
  AppointmentView cancelByPatient(UUID id) {
    var appointment = find(id);
    if ("CANCELLED".equals(appointment.status)) {
      throw conflict("ALREADY_CANCELLED", "Appointment is already cancelled");
    }
    if (!RESCHEDULABLE.contains(appointment.status)) {
      throw conflict(
          "INVALID_STATUS_TRANSITION", "Only booked or confirmed appointments can be cancelled");
    }
    appointment.status = "CANCELLED";
    appointments.saveAndFlush(appointment);
    audit.record(
        actorId(), "APPOINTMENT_CANCELLED", "APPOINTMENT", appointment.id, "ALLOWED", ONLINE);
    return AppointmentView.of(appointment);
  }

  @Transactional(readOnly = true)
  java.util.Optional<AppointmentView> findView(UUID id) {
    return appointments.findById(id).filter(clinic::hasAppointment).map(AppointmentView::of);
  }

  private ClinicService activeService(String serviceName) {
    var service =
        services
            .findByClinicIdAndName(clinicId(), serviceName)
            .orElseThrow(() -> conflict("UNKNOWN_SERVICE", "Service is not in the catalog"));
    // Выключенная услуга не предлагается в новой записи; старые записи её снимок сохраняют.
    if (!service.active) throw conflict("SERVICE_INACTIVE", "The service is switched off");
    return service;
  }

  /**
   * Общая часть создания записи. {@code online} — запись из бота: подтверждение пациент уже видел в
   * боте, поэтому в outbox ставится только напоминание за сутки.
   */
  private AppointmentView book(
      UUID patientId,
      UUID practitionerId,
      Instant startsAt,
      Instant endsAt,
      ClinicService service,
      String reason,
      boolean online) {
    checkSlot(practitionerId, startsAt, endsAt, null);
    try {
      var appointment =
          appointments.saveAndFlush(
              new Appointment(
                  patientId,
                  practitionerId,
                  startsAt,
                  endsAt,
                  service.name,
                  service.priceMinor,
                  service.currency));
      careRelationships.ensureCareRelationship(appointment.practitionerId, appointment.patientId);
      audit.record(
          actorId(), "APPOINTMENT_CREATED", "APPOINTMENT", appointment.id, "ALLOWED", reason);
      // Подтверждение и, если запись на будущий день, напоминание за сутки. Текст и адрес
      // собирает доставщик outbox из записи.
      if (online) outbox.appointmentBookedOnline(appointment.id, appointment.startsAt);
      else outbox.appointmentBooked(appointment.id, appointment.startsAt);
      return AppointmentView.of(appointment);
    } catch (DataIntegrityViolationException ex) {
      // Гонка двух записей на один слот: её ловит exclusion constraint PostgreSQL.
      throw conflict("SLOT_ALREADY_BOOKED", "The practitioner's slot is already booked");
    }
  }

  /**
   * Перенос без смены статуса. В outbox перенос ничего не кладёт: доставщик сам отменит
   * неотправленное подтверждение на старое время и поставит новое.
   */
  @Transactional
  AppointmentView reschedule(UUID id, RescheduleRequest request) {
    requireRole("ADMINISTRATOR");
    var appointment = find(id);
    if (!RESCHEDULABLE.contains(appointment.status)) {
      throw conflict(
          "INVALID_STATUS_TRANSITION", "Only booked or confirmed appointments can be rescheduled");
    }
    checkSlot(request.practitionerId(), request.startsAt(), request.endsAt(), appointment.id);
    var reason =
        RescheduleReason.code(
            appointment.startsAt,
            request.startsAt(),
            !appointment.practitionerId.equals(request.practitionerId()));
    appointment.startsAt = request.startsAt();
    appointment.endsAt = request.endsAt();
    appointment.practitionerId = request.practitionerId();
    try {
      appointments.saveAndFlush(appointment);
    } catch (DataIntegrityViolationException ex) {
      throw conflict("SLOT_ALREADY_BOOKED", "The practitioner's slot is already booked");
    }
    careRelationships.ensureCareRelationship(appointment.practitionerId, appointment.patientId);
    audit.record(
        actorId(), "APPOINTMENT_RESCHEDULED", "APPOINTMENT", appointment.id, "ALLOWED", reason);
    return AppointmentView.of(appointment);
  }

  @Transactional
  AppointmentView cancel(UUID id) {
    requireRole("ADMINISTRATOR");
    var appointment = find(id);
    if ("CANCELLED".equals(appointment.status)) {
      throw conflict("ALREADY_CANCELLED", "Appointment is already cancelled");
    }
    if (!AppointmentStatusPolicy.ACTIVE.contains(appointment.status)) {
      throw conflict(
          "INVALID_STATUS_TRANSITION", "Completed or missed appointments cannot be cancelled");
    }
    appointment.status = "CANCELLED";
    audit.record(
        actorId(), "APPOINTMENT_CANCELLED", "APPOINTMENT", appointment.id, "ALLOWED", "cancel");
    outbox.appointmentCancelled(appointment.id, appointment.startsAt);
    return AppointmentView.of(appointment);
  }

  /** При переходе в COMPLETED модуль оплаты создаёт счёт на снимок цены записи. */
  @Transactional
  AppointmentView changeStatus(UUID id, String target) {
    requireRole("ADMINISTRATOR", "DOCTOR");
    var appointment = find(id);
    var permitted =
        (hasRole("ADMINISTRATOR") && AppointmentStatusPolicy.administratorMay(target))
            || (hasRole("DOCTOR")
                && AppointmentStatusPolicy.doctorMay(target)
                && actorId().equals(appointment.practitionerId));
    if (!permitted) {
      audit.record(
          actorId(), "APPOINTMENT_STATUS_CHANGE", "APPOINTMENT", id, "DENIED", "to " + target);
      throw forbidden("STATUS_CHANGE_FORBIDDEN", "Role cannot change this status");
    }
    if (!AppointmentStatusPolicy.allowed(appointment.status, target)) {
      throw conflict(
          "INVALID_STATUS_TRANSITION",
          "Cannot move appointment from " + appointment.status + " to " + target);
    }
    var from = appointment.status;
    appointment.status = target;
    appointments.saveAndFlush(appointment);
    audit.record(
        actorId(),
        "APPOINTMENT_STATUS_CHANGED",
        "APPOINTMENT",
        appointment.id,
        "ALLOWED",
        from + "->" + target);
    if ("COMPLETED".equals(target) && appointment.amountMinor != null) {
      charges.chargeForCompletedVisit(
          appointment.id, appointment.amountMinor, appointment.currency);
    }
    return AppointmentView.of(appointment);
  }

  /**
   * Старт приёма врачом: запись до приёма переводится в IN_PROGRESS. Уже идущий приём не меняется;
   * другие записи того же врача остаются как есть.
   */
  @Transactional
  void markInProgress(UUID id) {
    var appointment = find(id);
    if ("IN_PROGRESS".equals(appointment.status)) return;
    if (!AppointmentStatusPolicy.allowed(appointment.status, "IN_PROGRESS")) {
      throw conflict(
          "INVALID_STATUS_TRANSITION",
          "Cannot start a visit for an appointment in status " + appointment.status);
    }
    var from = appointment.status;
    appointment.status = "IN_PROGRESS";
    appointments.saveAndFlush(appointment);
    audit.record(
        actorId(),
        "APPOINTMENT_STATUS_CHANGED",
        "APPOINTMENT",
        appointment.id,
        "ALLOWED",
        from + "->IN_PROGRESS");
  }

  /** Длина интервала, врач, рабочие часы и пересечение — общие для создания и переноса. */
  private void checkSlot(UUID practitionerId, Instant startsAt, Instant endsAt, UUID excludedId) {
    if (!endsAt.isAfter(startsAt)) {
      throw conflict("INVALID_INTERVAL", "Appointment end must be after its start");
    }
    if (!clinic.hasPractitioner(practitionerId)) {
      throw notFound("PRACTITIONER_NOT_FOUND", "Practitioner not found");
    }
    // Запись в прошлое и перенос в прошлое не принимаются: время приёма уже прошло.
    if (startsAt.isBefore(time.now())) {
      throw conflict("APPOINTMENT_IN_PAST", "The appointment time has already passed");
    }
    if (!WorkingHoursPolicy.fits(
        workingHours.findByPractitionerIdOrderByDayOfWeek(practitionerId),
        startsAt,
        endsAt,
        time.zone())) {
      throw conflict("OUTSIDE_WORKING_HOURS", "Outside the practitioner's working hours");
    }
    var overlaps =
        excludedId == null
            ? appointments.countOverlaps(practitionerId, startsAt, endsAt)
            : appointments.countOverlapsExcluding(practitionerId, startsAt, endsAt, excludedId);
    if (overlaps > 0) {
      throw conflict("SLOT_ALREADY_BOOKED", "The practitioner's slot is already booked");
    }
  }

  private Appointment find(UUID id) {
    return appointments
        .findById(id)
        .filter(clinic::hasAppointment)
        .orElseThrow(() -> notFound("APPOINTMENT_NOT_FOUND", "Appointment not found"));
  }
}
