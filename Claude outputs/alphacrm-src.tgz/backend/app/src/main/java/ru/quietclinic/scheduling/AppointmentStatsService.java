package ru.quietclinic.scheduling;

import static ru.quietclinic.platform.PlatformConfig.conflict;
import static ru.quietclinic.platform.PlatformConfig.requireRole;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.quietclinic.platform.ClinicTime;

/** Агрегаты по записям без персональных данных: только дата, врач, статус и количество. */
@Service
class AppointmentStatsService {
  static final int MAX_RANGE_DAYS = 366;

  private final AppointmentRepository appointments;
  private final ClinicScope clinic;
  private final ClinicTime time;

  AppointmentStatsService(AppointmentRepository appointments, ClinicScope clinic, ClinicTime time) {
    this.appointments = appointments;
    this.clinic = clinic;
    this.time = time;
  }

  @Transactional(readOnly = true)
  AppointmentStatsView stats(LocalDate from, LocalDate to, UUID practitionerId) {
    requireRole("MANAGER", "ADMINISTRATOR");
    if (to.isBefore(from)) {
      throw conflict("INVALID_RANGE", "Period end must not be before its start");
    }
    if (ChronoUnit.DAYS.between(from, to) >= MAX_RANGE_DAYS) {
      throw conflict("RANGE_TOO_LONG", "Period must not exceed one year");
    }
    var inRange =
        appointments.findByStartsAtGreaterThanEqualAndStartsAtLessThanOrderByStartsAt(
            time.startOf(from), time.startOf(to.plusDays(1)));
    var ownPractitioners = clinic.practitionerIds();
    var filtered =
        inRange.stream()
            .filter(a -> ownPractitioners.contains(a.practitionerId))
            .filter(a -> practitionerId == null || a.practitionerId.equals(practitionerId))
            .toList();
    return new AppointmentStatsView(from, to, aggregate(filtered, time.zone()));
  }

  /** Группирует записи по дню (UTC), врачу и статусу. */
  static List<AppointmentStatRow> aggregate(List<Appointment> appointments) {
    return aggregate(appointments, ZoneOffset.UTC);
  }

  /** Группирует записи по дню в поясе клиники, врачу и статусу. */
  static List<AppointmentStatRow> aggregate(List<Appointment> appointments, ZoneId zone) {
    return appointments.stream()
        .collect(
            Collectors.groupingBy(
                a -> new Key(LocalDate.ofInstant(a.startsAt, zone), a.practitionerId, a.status),
                Collectors.counting()))
        .entrySet()
        .stream()
        .map(
            e ->
                new AppointmentStatRow(
                    e.getKey().date(),
                    e.getKey().practitionerId(),
                    e.getKey().status(),
                    e.getValue()))
        .sorted(
            Comparator.comparing(AppointmentStatRow::date)
                .thenComparing(r -> r.practitionerId().toString())
                .thenComparing(AppointmentStatRow::status))
        .toList();
  }

  private record Key(LocalDate date, UUID practitionerId, String status) {}
}
